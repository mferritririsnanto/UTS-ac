(() => {
'use strict';
const $ = id => document.getElementById(id);
const state = { running:false, paused:false, sw:false, ac:false, field:true, graph:true, t:0, i:0, prevI:0, eps:0, hist:[], last:0, raf:0 };
const P = { V:12, R:20, L:.5, f:1, N:500, A:0.0001, len:.2, mu:1, speed:1 };
const mu0=4*Math.PI*1e-7;
const fmt=(x,n=3)=>Number.isFinite(x)?x.toLocaleString('id-ID',{maximumFractionDigits:n}):'—';
function inductance(){return $('lm').value==='sol'?mu0*Number(P.mu)*P.N*P.N*P.A/P.len:P.L}
function source(t){return P.V*(state.ac?Math.sin(2*Math.PI*P.f*t):1)}
function ip(t){const L=Math.max(inductance(),1e-8),R=Math.max(P.R,1e-8); if(!state.sw)return 0;if(!state.ac)return P.V/R; const w=2*Math.PI*P.f; return P.V/Math.sqrt(R*R+(w*L)**2)*Math.sin(w*t-Math.atan2(w*L,R));}
function addControl(key,label,min,max,step,unit){
 const host=$('controls'), wrap=document.createElement('label'); wrap.innerHTML=`${label}: <span id="val-${key}"></span> ${unit||''}<div class="row"><input id="range-${key}" type="range" min="${min}" max="${max}" step="${step}" value="${P[key]}"><input id="num-${key}" type="number" min="${min}" max="${max}" step="${step}" value="${P[key]}"></div>`;host.append(wrap);
 const update=v=>{P[key]=Number(v);$('range-'+key).value=v;$('num-'+key).value=v;$('val-'+key).textContent=fmt(P[key],4);refresh();};
 $('range-'+key).addEventListener('input',e=>update(e.target.value));$('num-'+key).addEventListener('change',e=>update(e.target.value));
 $('val-'+key).textContent=fmt(P[key],4);
}
function setupControls(){addControl('V','Tegangan sumber',1,24,.5,'V');addControl('R','Resistansi',1,100,1,'Ω');addControl('L','Induktansi',.01,2,.01,'H');addControl('f','Frekuensi AC',.1,10,.1,'Hz');addControl('N','Jumlah lilitan',100,2000,50,'lilitan');addControl('A','Luas penampang',.00001,.001,.00001,'m²');addControl('len','Panjang solenoida',.05,1,.01,'m');}
function setTab(name){document.querySelectorAll('.tab').forEach(x=>x.classList.toggle('on',x.id===name));document.querySelectorAll('#tabs [data-t]').forEach(b=>b.classList.toggle('on',b.dataset.t===name));}
function initContent(){
 $('teori').innerHTML='<h2>Teori Induksi Diri</h2><p>Induksi diri adalah timbulnya GGL pada kumparan ketika arus yang melaluinya berubah. Menurut Hukum Lenz, GGL induksi menentang perubahan arus penyebabnya.</p><p>Induktor menyimpan energi dalam medan magnet. Pada rangkaian RL, arus tidak langsung mencapai nilai tunak karena induktor menentang perubahan arus.</p><h3>Konstanta waktu</h3><p>τ = L/R. Setelah satu konstanta waktu, arus pengisian DC mencapai sekitar 63,2% nilai tunaknya.</p>';
 $('rumus').innerHTML='<h2>Rumus Utama</h2><p class="eq">εL = −L (di/dt)</p><p class="eq">L = μ₀ μr N² A / ℓ</p><p class="eq">W = ½ L i²</p><p class="eq">τ = L/R</p><p class="eq">XL = 2πfL</p><p class="eq">Z = √(R² + XL²), Iₘ = Vₘ/Z</p><p>εL adalah GGL induksi (V), L induktansi (H), i arus (A), W energi magnet (J), R resistansi (Ω), dan f frekuensi (Hz).</p>';
 $('eksp').innerHTML='<h2>Eksperimen</h2><p>Ubah satu parameter pada panel Simulasi, lalu amati arus dan energi.</p><ol><li>Bandingkan arus untuk R kecil dan R besar.</li><li>Bandingkan konstanta waktu untuk dua nilai L.</li><li>Ubah frekuensi AC dan amati reaktansi induktif.</li><li>Pilih model solenoida, lalu ubah jumlah lilitan N.</li><li>Bandingkan inti udara dan inti besi.</li><li>Matikan sakelar dan amati peluruhan arus.</li></ol>';
 const qs=[['Apa satuan induktansi?',['Ohm','Henry','Watt'],1],['Hukum Lenz menyatakan GGL induksi…',['Menentang perubahan fluks/arus','Selalu menambah arus','Tidak memiliki arah'],0],['Rumus konstanta waktu RL adalah…',['R/L','L/R','LR'],1],['Energi induktor adalah…',['Li','½Li²','I²/R'],1],['Reaktansi induktif adalah…',['2πfL','R/L','V/R'],0],['Jika L naik, τ (R tetap)…',['Turun','Tetap','Naik'],2],['Arus tunak DC ideal adalah…',['V/R','V/L','L/R'],0],['GGL induksi bergantung pada…',['Nilai arus saja','Laju perubahan arus','Resistansi saja'],1],['Inti dengan permeabilitas lebih besar umumnya…',['Menurunkan L','Menaikkan L','Tidak berpengaruh'],1],['Saat sakelar dibuka pada model ini, arus…',['Langsung nol','Meluruh eksponensial','Naik tanpa batas'],1],['Daya reaktif induktor ideal rata-rata satu siklus…',['Nol','Selalu positif','Selalu negatif'],0]];
 $('kuis').innerHTML='<h2>Kuis: Induksi Diri</h2><p>Jawab pertanyaan berikut lalu tekan Periksa jawaban.</p>'+qs.map((q,i)=>`<div class="q"><p><b>${i+1}. ${q[0]}</b></p>${q[1].map((a,j)=>`<label><input type="radio" name="q${i}" value="${j}"> ${a}</label>`).join('')}</div>`).join('')+'<button id="check-quiz">Periksa jawaban</button> <span id="quiz-result" aria-live="polite"></span>';
 $('check-quiz').addEventListener('click',()=>{let score=0;qs.forEach((q,i)=>{const v=document.querySelector(`input[name="q${i}"]:checked`);if(v&&Number(v.value)===q[2])score++;});$('quiz-result').textContent=`Nilai: ${score}/${qs.length} (${Math.round(score/qs.length*100)}%)`;});
}
function refresh(){
 P.mu=Number($('core-sel').value);
 const L=inductance(), tau=L/P.R, XL=2*Math.PI*P.f*L, Z=Math.sqrt(P.R**2+XL**2), Im=P.V/Z;
 $('res-list').innerHTML=[['Tegangan sumber',fmt(P.V)+' V'],['Resistansi R',fmt(P.R)+' Ω'],['Induktansi L',fmt(L,6)+' H'],['Konstanta waktu τ=L/R',fmt(tau)+' s'],['Arus tunak DC V/R',fmt(P.V/P.R)+' A'],['Reaktansi XL',fmt(XL)+' Ω'],['Impedansi AC Z',fmt(Z)+' Ω'],['Amplitudo arus AC',fmt(Im)+' A'],['Arus saat ini',fmt(state.i)+' A'],['Energi magnet W=½Li²',fmt(.5*L*state.i**2)+' J'],['GGL induksi ε=−L di/dt',fmt(state.eps)+' V']].map(a=>`<dt>${a[0]}</dt><dd>${a[1]}</dd>`).join('');
 $('b-sw').textContent='Sakelar: '+(state.sw?'ON':'OFF');$('b-sw').setAttribute('aria-pressed',state.sw);
 $('b-mode').textContent='Mode: '+(state.ac?'AC':'DC');$('b-field').textContent='Medan: '+(state.field?'tampil':'sembunyi');$('b-field').setAttribute('aria-pressed',state.field);$('field').style.display=state.field?'':'none';$('core').setAttribute('opacity',P.mu>1?'0.55':'0');
 $('b-graph').textContent='Grafik: '+(state.graph?'tampil':'sembunyi');$('b-graph').setAttribute('aria-pressed',state.graph);$('gbox').style.display=state.graph?'':'none';
 $('srcdc').style.display=state.ac?'none':'';$('srcac').style.display=state.ac?'':'none';
 $('amm').textContent=fmt(state.i)+' A';$('vol').textContent=fmt(source(state.t)-P.R*state.i)+' V';$('emf').textContent=`t = ${fmt(state.t)} s | εL = ${fmt(state.eps)} V | Energi magnet = ${fmt(.5*L*state.i**2)} J`;
 $('status').textContent=state.running?(state.paused?'Simulasi dijeda.':'Simulasi berjalan.'):'Tekan Mulai untuk menjalankan simulasi.';
 drawCoil();drawAllGraphs();
}
function drawCoil(){const el=$('coil');el.innerHTML='';for(let k=0;k<8;k++){const path=document.createElementNS('http://www.w3.org/2000/svg','path');path.setAttribute('d',`M548 ${105+k*18} q24 9 24 18 q-24 9 -24 18`);el.append(path);}}
function drawCanvas(id,series,title,yLabel){const c=$(id);if(!c)return;const rect=c.getBoundingClientRect(),w=Math.max(280,Math.floor(rect.width||300)),h=220,dpr=window.devicePixelRatio||1;c.width=w*dpr;c.height=h*dpr;const ctx=c.getContext('2d');ctx.scale(dpr,dpr);ctx.clearRect(0,0,w,h);const cs=getComputedStyle(document.body),fg=cs.getPropertyValue('--fg'),grid=cs.getPropertyValue('--grid');ctx.strokeStyle=grid;ctx.fillStyle=fg;ctx.font='12px system-ui';ctx.lineWidth=1;for(let k=0;k<5;k++){let y=25+k*(h-50)/4;ctx.beginPath();ctx.moveTo(36,y);ctx.lineTo(w-8,y);ctx.stroke();}ctx.fillText(title,8,15);ctx.fillText(yLabel,5, h-5);if(series.length<2)return;const max=Math.max(.001,...series.map(x=>Math.abs(x.v)));ctx.strokeStyle='#4a3fd8';ctx.lineWidth=2;ctx.beginPath();series.forEach((p,i)=>{let x=36+i*(w-48)/(series.length-1),y= h/2-p.v/max*(h/2-30);if(i===0)ctx.moveTo(x,y);else ctx.lineTo(x,y);});ctx.stroke();}
function drawAllGraphs(){const h=state.hist.slice(-180);drawCanvas('c1',h.map(x=>({v:x.i})),'Arus terhadap waktu','I (A)');drawCanvas('c2',h.map(x=>({v:x.e})),'GGL induksi terhadap waktu','ε (V)');drawCanvas('g1',h.map(x=>({v:x.i})),'Arus i(t)','A');drawCanvas('g2',h.map(x=>({v:x.vr})),'Tegangan resistor vR','V');drawCanvas('g3',h.map(x=>({v:x.vl})),'Tegangan induktor vL','V');drawCanvas('g4',h.map(x=>({v:x.w})),'Energi magnet W','J');}
function step(dt){const L=Math.max(inductance(),1e-8),R=P.R,tau=L/R,old=state.i,t=state.t;state.t+=dt;let next;if(!state.sw){next=old*Math.exp(-dt/tau);if(Math.abs(next)<1e-7)next=0;}else if(!state.ac){const iss=P.V/R;next=iss+(old-iss)*Math.exp(-dt/tau);}else{const w=2*Math.PI*P.f,den=R*R+(w*L)**2,ipNow=P.V*(R*Math.sin(w*state.t)-w*L*Math.cos(w*state.t))/den;const ipOld=P.V*(R*Math.sin(w*t)-w*L*Math.cos(w*t))/den;next=ipNow+(old-ipOld)*Math.exp(-dt/tau);}state.i=next;state.eps=-L*(state.i-old)/dt;state.hist.push({t:state.t,i:state.i,e:state.eps,vr:R*state.i,vl:source(state.t)-R*state.i,w:.5*L*state.i**2});if(state.hist.length>500)state.hist.shift();}
function frame(now){if(!state.running||state.paused){state.raf=0;return;}const dt=Math.min(.04,Math.max(.001,(now-(state.last||now))/1000))*Number($('speed').value);state.last=now;step(dt);refresh();state.raf=requestAnimationFrame(frame);}
function start(){if(!state.running){state.running=true;state.paused=false;state.last=0;state.raf=requestAnimationFrame(frame);}else if(state.paused){state.paused=false;state.last=0;state.raf=requestAnimationFrame(frame);}state.sw=true;refresh();}
function reset(){state.running=false;state.paused=false;state.sw=false;state.t=0;state.i=0;state.eps=0;state.hist=[];if(state.raf)cancelAnimationFrame(state.raf);state.raf=0;refresh();}
document.querySelectorAll('#tabs [data-t]').forEach(b=>b.addEventListener('click',()=>setTab(b.dataset.t)));
$('theme').addEventListener('click',()=>{document.documentElement.dataset.theme=document.documentElement.dataset.theme==='dark'?'light':'dark';refresh();});
$('b-start').addEventListener('click',start);
$('b-pause').addEventListener('click',()=>{if(state.running){state.paused=true;refresh();}});
$('b-resume').addEventListener('click',()=>{if(state.running&&state.paused){state.paused=false;state.last=0;state.raf=requestAnimationFrame(frame);refresh();}else if(!state.running)start();});
$('b-reset').addEventListener('click',reset);
$('b-sw').addEventListener('click',()=>{state.sw=!state.sw;if(!state.sw){/* arus meluruh eksponensial */}else if(!state.running){state.running=true;state.paused=true;}refresh();});
$('b-mode').addEventListener('click',()=>{state.ac=!state.ac;refresh();});
$('b-field').addEventListener('click',()=>{state.field=!state.field;refresh();});
$('b-graph').addEventListener('click',()=>{state.graph=!state.graph;refresh();});
$('lm').addEventListener('change',refresh);$('core-sel').addEventListener('change',refresh);$('speed').addEventListener('change',()=>{});
window.addEventListener('resize',()=>{if(state.hist.length)drawAllGraphs();});
setupControls();initContent();refresh();
})();